from .main import (
    treat_regression_model,
    treat_multicollinearity,
    treat_pvalue
)